package com.personal.chatapp.network;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;

import com.personal.chatapp.utils.ConfigReader;

public class Server {
	ServerSocket serverSocket;
	ArrayList<ServerWorker> workers = new ArrayList<>();
	
	public Server() throws IOException {
		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server start and waiting for the client to join...");
		handleClientRequest();
	}
	
	public void handleClientRequest() throws IOException {
		while(true) {
			Socket clientSocket = serverSocket.accept(); // Handshaking
			// Per client per thread
			ServerWorker serverWorker = new ServerWorker(clientSocket, this );// Creating a new worker
			workers.add(serverWorker);
			serverWorker.start();
		}
	}

	// for Single client
	/*
	public Server() throws IOException {
		int PORT = Integer.parseInt(ConfigReader.getValue("PORTNO"));
		serverSocket = new ServerSocket(PORT);
		System.out.println("Server started and waiting for the Client Connection...");
		Socket socket = serverSocket.accept(); // Handshaking
		System.out.println("Client joins the Server");
		InputStream in = socket.getInputStream();//read bytes from the network
		byte  arr[] = in.readAllBytes();
		String str = new String(arr);
		System.out.println("Message Rec From the client " + str);
		in.close();
		socket.close();
	}*/
	public static void main(String[] args) throws IOException {
		Server server = new Server();
	}
}
