package com.personal.chatapp.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;

// Thread == Worker
public class ServerWorker extends Thread {

	private Socket clientSocket;
	private InputStream in;
	private OutputStream out;
	private Server server;
	public ServerWorker(Socket clientSocket, Server server) throws IOException {
		this.server = server;
		this.clientSocket = clientSocket;
		in = clientSocket.getInputStream(); // client Data Read
		out = clientSocket.getOutputStream();// client Data Write
		System.out.println("New Client comes");
	}

	@Override
	public void run() {
		// Read data from the client and broadcast the data to all
		BufferedReader br = new BufferedReader(new InputStreamReader(in));
		String line;
		try {
		while(true) {
				line = br.readLine();// \n
				System.out.println("Line Read... " + line);
				if(line.equalsIgnoreCase("quit")) {
					break;
				}
//				out.write(line.getBytes());
				// Broadcast to all
				for(ServerWorker serverworker : server.workers) {
					line = line + "\n"; 
					serverworker.out.write(line.getBytes());
				}
			} 
		}catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		finally {
			try {
			if(br!=null) {
				br.close();
			}
			if(in!=null) {
				in.close();
			}
			if(out!=null) {
				out.close();
			}
			if(clientSocket!= null) {
				clientSocket.close();
			}
			}
			catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}
}
