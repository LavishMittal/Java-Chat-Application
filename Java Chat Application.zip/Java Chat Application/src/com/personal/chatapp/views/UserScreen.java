package com.personal.chatapp.views;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.personal.chatapp.dao.UserDAO;
import com.personal.chatapp.dto.UserDTO;
import com.personal.chatapp.utils.UserInfo;

public class UserScreen extends JFrame{
	private JTextField useridtxt;
	private JPasswordField passwordField;

	public static void main(String[] args) {
		UserScreen window = new UserScreen();	
		
	}
	UserDAO userDAO = new UserDAO();
	private void doLogin() {
		String userid = useridtxt.getText();
		char[] password = passwordField.getPassword();
		UserDTO userDTO = new UserDTO(userid,password);
		
		try {
			String message =" ";
			if(userDAO.isLogin(userDTO)){
				message = "Welcome " + userid;
				UserInfo.USER_NAME = userid;
				JOptionPane.showMessageDialog(this, message);
				setVisible(false);
				dispose();
				DashBoard dashboard = new DashBoard(message);
				dashboard.setVisible(true);
			}
			else {
				message = "Invalid Userid or password";
				JOptionPane.showMessageDialog(this, message);
			}
//			JOptionPane.showMessageDialog(this, message);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void register() {
		String userid = useridtxt.getText();
		char[] password = passwordField.getPassword();
//		UserDAO userDAO = new UserDAO();
		UserDTO userDTO = new UserDTO(userid,password);
		try {
			int result = userDAO.add(userDTO);
			if(result>0) {
				JOptionPane.showMessageDialog(this, "Register Successfully ");
			}
			else {
				JOptionPane.showMessageDialog(this, "Register Fail");
			}
		}
		catch(ClassNotFoundException | SQLException ex) {
			System.out.println("DB issue...");
			ex.printStackTrace();
		}
		catch(Exception ex) {
			System.out.println("Some Generic exception Raised...");
			ex.printStackTrace();
		}
		System.out.println("userid " + userid + " Password " + password);
	}

	/**
	 * Create the application.
	 */
	public UserScreen() {
		setResizable(false);
		setTitle("Login");
		getContentPane().setBackground(new Color(255, 255, 255));
		getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOGIN");
		lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 40));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(213, 23, 242, 102);
		getContentPane().add(lblNewLabel);
		
		useridtxt = new JTextField();
		useridtxt.setBounds(354, 146, 242, 32);
		getContentPane().add(useridtxt);
		useridtxt.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("User Id");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(110, 146, 135, 32);
		getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Password");
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(110, 228, 135, 32);
		getContentPane().add(lblNewLabel_1_1);
		
		JButton btnNewButton = new JButton("Login");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				doLogin();
			}
		});
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setBounds(182, 324, 115, 32);
		getContentPane().add(btnNewButton);
		
		JButton btnRegister = new JButton("Register");
		btnRegister.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				register();
			}
		});
		btnRegister.setFont(new Font("Tahoma", Font.PLAIN, 16));
		btnRegister.setBackground(new Color(255, 255, 255));
		btnRegister.setBounds(354, 324, 150, 32);
		getContentPane().add(btnRegister);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(354, 228, 242, 32);
		getContentPane().add(passwordField);
		setBounds(100, 100, 684, 437);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
}
